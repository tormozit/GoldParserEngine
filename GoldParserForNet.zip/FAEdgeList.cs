using System.Collections.Generic;

namespace GoldParserEngine
{
    internal class FAEdgeList : List<FAEdge>
    {
    }
}