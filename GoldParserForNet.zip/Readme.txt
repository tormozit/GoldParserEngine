﻿This code is a conversion from VB.NET to C# (with some modifications) of the Gold Parser Engine written by Devin D. Cook
http://goldparser.org/engine/5/net/index.htm