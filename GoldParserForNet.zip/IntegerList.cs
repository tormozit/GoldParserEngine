using System.Collections.Generic;

namespace GoldParserEngine
{
    internal class IntegerList : List<int>
    {
    }
}